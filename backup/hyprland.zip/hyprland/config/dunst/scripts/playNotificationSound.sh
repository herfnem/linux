#!/bin/bash

canberra-gtk-play -i message