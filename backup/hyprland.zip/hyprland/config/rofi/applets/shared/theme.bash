## Current Theme

type="$HOME/.config/rofi/applets/type-4"
style='style-3.rasi'
